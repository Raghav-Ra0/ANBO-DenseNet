from keras.layers import Input, Conv2D, BatchNormalization, Dense
from keras.layers import AvgPool2D, GlobalAveragePooling2D, MaxPool2D
from keras.models import Model
from keras.layers import ReLU, concatenate
import keras.backend as K
from Proposed import ANBO
import numpy as np
from keras.optimizers import Adam as Opt


# Creating Densenet121
def Classify(x_train, x_test, y_train, y_test, ACC, TPR, TNR, filters=32):
    print("Proposed method...")
    n_classes = 1
    epoch = 10

    # batch norm + relu + conv
    def bn_rl_conv(x, filters, kernel=1, strides=1):
        x = BatchNormalization()(x)
        x = ReLU()(x)
        x = Conv2D(filters, kernel, strides=strides, padding='same')(x)
        return x

    def dense_block(x, repetition):
        for _ in range(repetition):
            y = bn_rl_conv(x, 4 * filters)
            y = bn_rl_conv(y, filters, 3)
            x = concatenate([y, x])
        return x

    def transition_layer(x):
        x = bn_rl_conv(x, K.int_shape(x)[-1] // 2)
        x = AvgPool2D(2, strides=2, padding='same')(x)
        return x

    input_shape = (112, 112, 3)
    input = Input(input_shape)

    x = Conv2D(64, 7, strides=2, padding='same')(input)
    x = MaxPool2D(3, strides=2, padding='same')(x)

    for repetition in [6, 12, 24, 16]:
        d = dense_block(x, repetition)
        x = transition_layer(d)
    x = GlobalAveragePooling2D()(d)
    output = Dense(n_classes, activation='softmax')(x)

    model = Model(input, output)

    x_test = np.resize(x_test, (len(x_test), 112, 112, 3))
    x_train = np.resize(x_train, (len(x_train), 112, 112, 3))
    model.compile(loss='categorical_crossentropy', optimizer=Opt(learning_rate=ANBO.optimize(epoch)),  metrics=['accuracy'])
    # tf.keras.utils.plot_model(model, to_file='Densenet.png', show_shapes=True, show_layer_names=True)
    from keras.preprocessing.image import ImageDataGenerator
    datagen = ImageDataGenerator(height_shift_range=0.1, width_shift_range=0.1, shear_range=0.2, zoom_range=0.2,
                                 horizontal_flip=True)
    datagen.fit(x_train)
    datagen.flow(x=x_train, y=y_train, batch_size=152)
    pred = model.predict(x_test)
    predict = pred.flatten()
    target = y_test

    tp, tn, fn, fp = 0, 0, 0, 0
    uni = np.unique(target)
    for j in range(len(uni)):
        c = uni[j]
        for i in range(len(target)):
            if target[i] == c and predict[i] == c:
                tp += 1
            if target[i] != c and predict[i] != c:
                tn += 1
            if target[i] == c and predict[i] != c:
                fn += 1
            if target[i] != c and predict[i] == c:
                fp += 1
    Accuracy = tp + tn / (tp + tn + fp + fn)
    Tpr = tp / (tp + fn)
    Tnr = tn / (tn + fp)
    ACC.append(Accuracy)
    TPR.append(Tpr)
    TNR.append(Tnr)

    return ACC, TPR, TNR


