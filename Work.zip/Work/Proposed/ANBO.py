import numpy as np
import random


def optimize(epoch):
    def generate(r, c, l, u):
        Data = []
        for row in range(r):
            tem = []
            for column in range(c):
                tem.append(random.uniform(l, u))
            Data.append(tem)
        return Data

    R, C, Lb, Ub = epoch, 5, 1, 5
    g, max_it = 0, 100
    soln = generate(R, C, Lb, Ub)

    def fitness(soln):     # objective function
        F = []
        for i in range(len(soln)):
            F.append(random.random())
        return F

    def capacity(Cmax, fit):
        pi = 3.14
        Capacity = []
        for i in range(len(Cmax)):
            ci = Cmax[i]*(np.sin((fit[i]-fmin)/(fmax-fmin))*(pi/2))
            Capacity.append(ci)
        return Capacity

    def movement(NB):
        mov = []
        for i in range(len(NB)):
            for j in range(len(NB[i])):
                mov.append(np.sqrt(np.sum(np.square(NB[i][j]))))
        return mov

    def Humidity(hum, di):
        pmax, itr = 10, 10
        p0 = 1
        Hum = []
        p = pmax-p0*(1-(itr/max_it)+random.uniform(0, 1))
        for i in range(len(hum)):
            for j in range(len(hum[i])):
                Hum.append(p*hum[i][j]*di[i])
        return Hum

    def nembi_new(Hum, Nb_old, Mov):
        Nb_new = []
        D = 5
        a = random.uniform(0, 1)
        for i in range(len(Nb_old)):
            for j in range(len(Nb_old[i])):
                Nb_new.append((1/(1-Hum[i]-(a*D))) * ((Nb_old[i][j]*(1-a*D))*(1-Hum[i])-Hum[i]-Mov[i]))   # update
        return Nb_new

    while g < max_it:
        fit = fitness(soln)

        fmin = min(fit)
        fmax = max(fit)
        Cmax = max(soln)
        cap = capacity(Cmax, fit)
        Mov = movement(soln)
        hum = Humidity(soln, Mov)
        Nb_new = nembi_new(hum, soln, Mov)
        bst = np.argmax(fit)
        best_soln = abs(Nb_new[bst])
        g += 1

        return best_soln

