import Aug_feat
from Proposed import Proposed_ANBO_DenseNet
from sklearn.model_selection import train_test_split


def callmain(tr):

    Feature, Label = Aug_feat.feature_extraction()                      # Read Feature Extracted Data

    ACC, TPR, TNR = [], [], []                                          # Create empty list for store Accuracy, TPR, TNR
    x_train, x_test, y_train, y_test = train_test_split(Feature, Label, train_size=tr)

    # Proposed method
    Proposed_ANBO_DenseNet.Classify(x_train, x_test, y_train, y_test, ACC, TPR, TNR)

    return ACC, TPR, TNR


if __name__ == '__main__':
    callmain(0.9)
