import glob, re
import os, matplotlib.pyplot as plt
import cv2, numpy as np, pyfeats
from scipy.stats import kurtosis, skew
from keras.models import Model
from keras.applications.vgg19 import VGG19 as CNN
from skimage.feature.texture import graycoprops
import lndp, SLBT


base_model = CNN(weights='imagenet')
model = Model(inputs=base_model.input, outputs=base_model.get_layer('block4_pool').output)
# -------- CNN Features --------
def CNN_based(images):
    x = images
    x = np.expand_dims(x, axis=0)                           # expand the dimension
    x = np.resize(x, (1, 224, 224, 3))                      # resize the image to required format
    block4_pool_features = model.predict(x)                 # size(1, 14, 14, 512)
    mean_block_feat = block4_pool_features.mean(1)          # (1, 14, 512)
    feature_vec = mean_block_feat.mean(1)                   # (1, 512)
    return feature_vec[0].tolist()


def e_feat(images):
    energy = graycoprops(images, 'energy')
    return np.mean(energy)


def homo_feat(images):
    homoginity = graycoprops(images, 'homogeneity')
    return np.mean(homoginity)


def mixup(x1, x2, y1, y2, lambda_=0.5):
    x = lambda_ * x1 + (1 - lambda_) * x2
    y = lambda_ * y1 + (1 - lambda_) * y2
    return x, y


def mixed_up(path1, path2):
    # mixup
    image_paths = []

    listing = os.listdir(path1)
    for file in listing:
        filename = os.path.join(path1, file)
        image_paths.append(filename)
    k = 1
    for i in range(len(listing)):
        if i == (len(listing)-1):
            x, y = mixup(cv2.imread(image_paths[i]), cv2.imread(image_paths[0]), np.array([1, 0]), np.array([0, 1]))
        else:
            x, y = mixup(cv2.imread(image_paths[i]), cv2.imread(image_paths[i+1]), np.array([1, 0]), np.array([0, 1]))
        x = x.astype(int)
        plt.imshow(x)
        # plt.show()
        out_filename1 = os.path.join(path2, str(k) + '.png')
        # cv2.imwrite(out_filename1, x)
        k = k+1


# ------------------ Mixup Augmentatin ---------------------
v = mixed_up('..../', '...\\Mixup')             # Segmented image path and output path


# ------------------- Feature €Extraction ------------------
im_path = glob.glob("Mixup//*")
im_path.sort(key=lambda f: int(re.sub('\D', '', f)))


f1, f2, f3, f4, f5, f6, f7 = [], [], [], [], [], [], []
f8, f9, f10, f11, f12, f13 = [], [], [], [], [], []
Feature, Feature1 = [], []

for file in im_path:
    i_file = os.path.join(os.getcwd(), file)
    img = cv2.imread(i_file)

    # Mean
    mean = np.mean(img)
    f1 = mean
    # Variance
    var = np.var(img)
    f2 = var
    # Kurtosis
    kur = np.array(kurtosis(img)).flatten()
    f3.append(kur[10:20])
    # Skewness
    skewness = np.array(skew(img)).flatten()
    f4.append(skewness[10:20])
    #  contrast
    img1 = np.resize(img, (img.shape[0], img.shape[1], img.shape[0]))
    features, features_range, labels, labels_range = pyfeats.glcm_features(img1, ignore_zeros=False)
    f5 = features[1]
    # Homogeneity
    img1 = np.resize(img, (img.shape[0], img.shape[1], 3, 1))
    f6 = homo_feat(img1)
    # Correlation
    f7 = features[2]
    # Entropy
    f8 = features[8]
    # Energy
    f9 = e_feat(img1)
    # ASM
    f10 = features[0]
    # Shape local binary texture
    slbt = SLBT.SLBT(img)
    f11.append(slbt[:10])
    # local neighbourhood difference pattern
    LNDP = lndp.lndp(img1)
    f12.append(LNDP[:10])
    # CNN
    cnn = CNN_based(img)
    f13.append(cnn[:10])

    F = [f1, f2, f5, f6, f7, f8, f9, f10]
    F1 = np.concatenate((f3, f4, f11, f12, f13), axis=1)
    Feature.append(F)
    Feature1.append(F1[0])
    np.save("mix1.npy", Feature)  # save output data into csv file
    np.save("mix2.npy", Feature1)










