from __future__ import absolute_import
from keras.layers import *
import os, cv2, numpy as np
from keras.utils import plot_model
from warnings import filterwarnings
filterwarnings(action='ignore', category=DeprecationWarning, message='`np.bool` is a deprecated alias')
from keras.optimizers import Adam as opt
os.environ["PATH"] += os.pathsep + 'C:/Program Files/Graphviz/bin/'
from keras_unet_collection.layer_utils import *
from keras.layers import Input
from keras.models import Model
import ANBO


def RR_CONV(X, channel, kernel_size=3, stack_num=2, recur_num=2, activation='ReLU', batch_norm=False, name='rr'):

    activation_func = eval(activation)

    layer_skip = Conv2D(channel, 1, name='{}_conv'.format(name))(X)
    layer_main = layer_skip

    for i in range(stack_num):

        layer_res = Conv2D(channel, kernel_size, padding='same', name='{}_conv{}'.format(name, i))(layer_main)

        if batch_norm:
            layer_res = BatchNormalization(name='{}_bn{}'.format(name, i))(layer_res)

        layer_res = activation_func(name='{}_activation{}'.format(name, i))(layer_res)

        for j in range(recur_num):

            layer_add = add([layer_res, layer_main], name='{}_add{}_{}'.format(name, i, j))

            layer_res = Conv2D(channel, kernel_size, padding='same', name='{}_conv{}_{}'.format(name, i, j))(
                layer_add)

            if batch_norm:
                layer_res = BatchNormalization(name='{}_bn{}_{}'.format(name, i, j))(layer_res)

            layer_res = activation_func(name='{}_activation{}_{}'.format(name, i, j))(layer_res)

        layer_main = layer_res

    out_layer = add([layer_main, layer_skip], name='{}_add{}'.format(name, i))

    return out_layer


def UNET_RR_left(X, channel, kernel_size=3,
                 stack_num=2, recur_num=2, activation='ReLU',
                 pool=True, batch_norm=False, name='left0'):
    pool_size = 2

    # maxpooling layer vs strided convolutional layers
    X = encode_layer(X, channel, pool_size, pool, activation=activation,
                     batch_norm=batch_norm, name='{}_encode'.format(name))

    # stack linear convolutional layers
    X = RR_CONV(X, channel, stack_num=stack_num, recur_num=recur_num,
                activation=activation, batch_norm=batch_norm, name=name)
    return X


def UNET_RR_right(X, X_list, channel, kernel_size=3,
                  stack_num=2, recur_num=2, activation='ReLU',
                  unpool=True, batch_norm=False, name='right0'):

    pool_size = 2

    X = decode_layer(X, channel, pool_size, unpool,
                     activation=activation, batch_norm=batch_norm, name='{}_decode'.format(name))

    # linear convolutional layers before concatenation
    X = CONV_stack(X, channel, kernel_size, stack_num=1, activation=activation,
                   batch_norm=batch_norm, name='{}_conv_before_concat'.format(name))

    # Tensor concatenation
    H = concatenate([X, ] + X_list, axis=-1, name='{}_concat'.format(name))

    # stacked linear convolutional layers after concatenation
    H = RR_CONV(H, channel, stack_num=stack_num, recur_num=recur_num,
                activation=activation, batch_norm=batch_norm, name=name)
    return H


def r2_unet_2d_base(input_tensor, filter_num, stack_num_down=2, stack_num_up=2, recur_num=2,
                    activation='ReLU', batch_norm=False, pool=True, unpool=True, name='res_unet'):

    activation_func = eval(activation)

    X = input_tensor
    X_skip = []

    # downsampling blocks
    X = RR_CONV(X, filter_num[0], stack_num=stack_num_down, recur_num=recur_num,
                activation=activation, batch_norm=batch_norm, name='{}_down0'.format(name))
    X_skip.append(X)

    for i, f in enumerate(filter_num[1:]):
        X = UNET_RR_left(X, f, kernel_size=3, stack_num=stack_num_down, recur_num=recur_num,
                         activation=activation, pool=pool, batch_norm=batch_norm,
                         name='{}_down{}'.format(name, i + 1))
        X_skip.append(X)

    # upsampling blocks
    X_skip = X_skip[:-1][::-1]
    for i, f in enumerate(filter_num[:-1][::-1]):
        X = UNET_RR_right(X, [X_skip[i], ], f, stack_num=stack_num_up, recur_num=recur_num,
                          activation=activation, unpool=unpool, batch_norm=batch_norm,
                          name='{}_up{}'.format(name, i + 1))

    return X


def r2_unet_2d(input_size, filter_num, n_labels,
               stack_num_down=2, stack_num_up=2, recur_num=2,
               activation='ReLU', output_activation='Softmax',
               batch_norm=False, pool=True, unpool=True, name='r2_unet'):

    activation_func = eval(activation)

    IN = Input(input_size, name='{}_input'.format(name))

    # base
    X = r2_unet_2d_base(IN, filter_num,
                        stack_num_down=stack_num_down, stack_num_up=stack_num_up, recur_num=recur_num,
                        activation=activation, batch_norm=batch_norm, pool=pool, unpool=unpool, name=name)
    # output layer
    OUT = CONV_output(X, n_labels, kernel_size=1, activation=output_activation, name='{}_output'.format(name))

    # functional API model
    model = Model(inputs=[IN], outputs=[OUT], name='{}_model'.format(name))

    return model


def train_R2_UNet(path1, path2):
    # --------------------------------- X Train ----------------------------------
    path = [path1]
    bpath = os.getcwd()  # current directory
    path_1 = os.path.join(bpath, path[0])
    d2 = os.listdir(os.path.join(path_1))
    files = []
    for j in range(len(d2)):
        filefullpath = os.path.join(path_1, d2[j])
        files.append(filefullpath)
    X_train = np.zeros((len(files), 120, 120, 3), dtype=np.uint8)

    Y_train = np.zeros((len(files), 120, 120, 1), dtype='bool')
    for i in range(len(files)):

        # read the image using skimage
        image = cv2.imread(files[i])
        image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        image = np.resize(image, (120, 120, 3))
        # use np.expand dims to add a channel axis so the shape becomes (IMG_HEIGHT, IMG_WIDTH, 1)
        # insert the image into X_train
        X_train[i] = image

    # ---------------------------------- Y train ---------------------------------------
    path = [path2]
    bpath = os.getcwd()  # current directory
    path_1 = os.path.join(bpath, path[0])
    d2 = os.listdir(os.path.join(path_1))
    files = []
    for j in range(len(d2)):
        filefullpath = os.path.join(path_1, d2[j])
        files.append(filefullpath)
    files.sort(key=lambda f: int(''.join(filter(str.isdigit, f))))

    for i in range(len(files)):
        image = cv2.imread(files[i])
        image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        image = np.resize(image, (120, 120))
        # use np.expand dims to add a channel axis so the shape becomes (IMG_HEIGHT, IMG_WIDTH, 1)
        image = np.expand_dims(image, axis=-1)
        # insert the image into Y_train
        Y_train[i] = image
    model = r2_unet_2d((120, 120, 3), [256, 132, 56, 32], n_labels=2)
    # model.summary()
    model.compile(loss='binary_crossentropy', optimizer=opt(ANBO.optimize()), metrics=['accuracy'])             # update
    # plot_model(model, to_file='model_R2UNet.png', show_shapes=True, show_layer_names=True)
    model.fit(X_train, Y_train, batch_size=100, epochs=20)
    # model.save('model.h5')


train_R2_UNet('Process/', 'Mask/')                  # Processed image and ground truth image path

