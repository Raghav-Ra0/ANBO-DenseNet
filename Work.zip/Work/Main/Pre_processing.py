import glob
import os, cv2, re
import matplotlib.pyplot as plt


def main(path1, path2):
    listing = os.listdir(path1)
    listing.sort(key=lambda f: int(re.sub('\D', '', f)))
    for file in listing:
        filename = os.path.join(path1, file)
        img = cv2.imread(filename)

        im1 = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        gray = cv2.cvtColor(im1, cv2.COLOR_BGR2GRAY)
        gray = gray.astype("uint8")
        ret, thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
        thresh = cv2.resize(thresh, (224, 224))
        for i in range(len(thresh)):
            for j in range(0, len(thresh)):
                if thresh[i][j] >= 1:
                    thresh[i][j] = 1
        plt.imshow(thresh, cmap="gray")
        # plt.show()
        out_filename1 = os.path.join(path2, file[:-3] + 'png')
        # cv2.imwrite(out_filename1, thresh)


File_path = glob.glob(".../")                       # input data path
File_path.sort(key=lambda f: int(re.sub('\D', '', f)))


count = 1
for file in File_path:
    file_p = os.path.join(os.getcwd(), file)

    img = cv2.imread(file_p)                                       # Read input data
    plt.imshow(img)
    # plt.show()

# ------- Pre_processing -------
    P_data = cv2.medianBlur(img, 7)                                # Median Filter
    # cv2.imwrite("Process/" + str(count) + ".png", P_data)
    count = count+1
    plt.imshow(P_data)
    # plt.show()








