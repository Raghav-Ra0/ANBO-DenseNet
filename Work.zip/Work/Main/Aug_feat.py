import glob, re
import os, matplotlib.pyplot as plt
import tensorflow as tf
import cv2, numpy as np, pyfeats
from PIL import ImageOps, Image
import albumentations as albu
from scipy.stats import kurtosis, skew
from keras.models import Model
from keras.applications.vgg19 import VGG19 as CNN
from skimage.feature.texture import graycoprops
from Main import lndp, SLBT
import pandas as pd


base_model = CNN(weights='imagenet')
model = Model(inputs=base_model.input, outputs=base_model.get_layer('block4_pool').output)
# -------- CNN Features --------
def CNN_based(images):
    x = images
    x = np.expand_dims(x, axis=0)                           # expand the dimension
    x = np.resize(x, (1, 224, 224, 3))                      # resize the image to required format
    block4_pool_features = model.predict(x)                 # size(1, 14, 14, 512)
    mean_block_feat = block4_pool_features.mean(1)          # (1, 14, 512)
    feature_vec = mean_block_feat.mean(1)                   # (1, 512)
    return feature_vec[0].tolist()


def e_feat(images):
    energy = graycoprops(images, 'energy')
    return np.mean(energy)


def homo_feat(images):
    homoginity = graycoprops(images, 'homogeneity')
    return np.mean(homoginity)


def feature():
    img_path = glob.glob("...../*")             # Segmented image data path
    img_path.sort(key=lambda f: int(re.sub('\D', '', f)))

    f1, f2, f3, f4, f5, f6, f7 = [], [], [], [], [], [], []
    f8, f9, f10, f11, f12, f13 = [], [], [], [], [], []
    Feature, Feature1 = [], []

    for i in img_path:
        img_p = os.path.join(os.getcwd(), i)
        img = cv2.imread(img_p)
        img1 = Image.open(img_p)

    # ----------- Image Augmentation ------------
    # random brightness
        Ir = np.array(tf.image.random_brightness(img, max_delta=0.1, seed=None))
        plt.imshow(Ir)
        # plt.show()

    # Shift scale rotate
        transform = albu.augmentations.geometric.transforms.ShiftScaleRotate(shift_limit=0.0625, scale_limit=0.5,
                                                                             rotate_limit=90)
        Is = transform(image=img)['image']
        plt.imshow(Is)
        # plt.show()

    # center crop flip
        w, h = img.shape[:2]
        wdif, hdif = (w - 50) // 2, (h - 50) // 2
        border = wdif, hdif, wdif, hdif                         # left, top, right, bottom
        cropped_img = np.array(ImageOps.crop(img1, border))     # Cropped image
        If = cv2.flip(cropped_img, 0)                           # Flip image
        plt.imshow(If, cmap='gray')
        # plt.show()

        Aug = [Ir, Is, If]

    # ------------ Feature Extraction ------------
        for i in range(len(Aug)):
            a_img = Aug[i]
    # Mean
            mean = np.mean(a_img)
            f1 = mean
    # Variance
            var = np.var(a_img)
            f2 = var
    # Kurtosis
            kur = np.array(kurtosis(a_img)).flatten()
            f3.append(kur[10:20])
    # Skewness
            skewness = np.array(skew(a_img)).flatten()
            f4.append(skewness[10:20])
    #  contrast
            img1 = np.resize(img, (img.shape[0], img.shape[1], img.shape[0]))
            features, features_range, labels, labels_range = pyfeats.glcm_features(img1, ignore_zeros=False)
            f5 = features[1]
    # Homogeneity
            img1 = np.resize(img, (img.shape[0], img.shape[1], 3, 1))
            f6 = homo_feat(img1)
    # Correlation
            f7 = features[2]
    # Entropy
            f8 = features[8]
    # Energy
            f9 = e_feat(img1)
    # ASM
            f10 = features[0]
    # Shape local binary texture
            slbt = SLBT.SLBT(a_img)
            f11.append(slbt[:10])
    # local neighbourhood difference pattern
            LNDP = lndp.lndp(img1)
            f12.append(LNDP[:10])
    # CNN
            cnn = CNN_based(a_img)
            f13.append(cnn[:10])

            F = [f1, f2, f5, f6, f7, f8, f9, f10]
            F1 = np.concatenate((f3, f4, f11, f12, f13), axis=1)
            Feature.append(F)
            Feature1.append(F1[0])
            # np.save("Feature1.npy", Feature)        # save output data into csv file
            # np.save("Feature2.npy", Feature1)


def feature_extraction():
    # feature()
    cutmix1 = np.load("cut1.npy")
    cutmix2 = np.load("cut2.npy")
    cutmix = np.concatenate((cutmix1, cutmix2), axis=1)
    mixup1 = np.load("mix1.npy")
    mixup2 = np.load("mix2.npy")
    mixup = np.concatenate((mixup1, mixup2), axis=1)
    Feat1 = np.load("Feature1.npy")
    Feat2 = np.load("Feature2.npy")
    Feat = np.concatenate((Feat1, Feat2), axis=1)

    Feature = np.concatenate((cutmix, mixup, Feat), axis=0)
    Feature = np.nan_to_num(Feature)
    Label = np.load("Label.npy")

    return Feature, Label


