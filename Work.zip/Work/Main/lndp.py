import numpy as np
import matplotlib.pyplot as plt


def lndp(img):
    x, y = img.shape[0], img.shape[1]
    result = np.zeros((x, y))

    for i in range(0, x):
        for j in range(0, y):
            mask = np.zeros((3, 3))

            if j <= 172 and i <= 172:
                if j + 1 <= y:
                    i1 = img[i, j + 1]
                    i1 = np.mean(i1)
                else:
                    i1 = 0
                if i + 1 <= x and j + 1 <= y:
                    i2 = img[i + 1, j + 1]
                    i2 = np.mean(i2)
                else:
                    i2 = 0
                if i + 1 <= x:
                    i3 = img[i + 1, j]
                    i3 = np.mean(i3)
                else:
                    i3 = 0
                if i + 1 <= x and j - 1 > 0:
                    i4 = img[i + 1, j - 1]
                    i4 = np.mean(i4)
                else:
                    i4 = 0
                if j - 1 > 0:
                    i5 = img[i, j - 1]
                    i5 = np.mean(i5)
                else:
                    i5 = 0
                if i - 1 > 0 and j - 1 > 0:
                    i6 = img[i - 1, j - 1]
                    i6 = np.mean(i6)
                else:
                    i6 = 0
                if i - 1 > 0:
                    i7 = img[i - 1, j]
                    i7 = np.mean(i7)
                else:
                    i7 = 0
                if i - 1 > 0 and j + 1 <= y:
                    i8 = img[i - 1, j + 1]
                    i8 = np.mean(i8)
                else:
                    i8 = 0
                if ((i8 - i1) >= 0 and (i2 - i1) >= 0) or ((i8 - i1) < 0 and (i2 - i1) < 0):
                    mask[1, 2] = 1
                else:
                    mask[1, 2] = 0

                if ((i3 - i2) >= 0 and (i1 - i2) >= 0) or ((i3 - i2) < 0 and (i1 - i2) < 0):
                    mask[2, 2] = 1
                else:
                    mask[2, 2] = 0

                if ((i4 - i3) >= 0 and (i2 - i3) >= 0) or ((i4 - i3) < 0 and (i2 - i3) < 0):
                    mask[2, 1] = 1
                else:
                    mask[2, 1] = 0

                if ((i5 - i4) >= 0 and (i3 - i4) >= 0) or ((i5 - i4) < 0 and (i3 - i4) < 0):
                    mask[2, 0] = 1
                else:
                    mask[2, 0] = 0

                if ((i4 - i5) >= 0 and (i6 - i5) >= 0) or ((i4 - i5) < 0 and (i6 - i5) < 0):
                    mask[1, 0] = 1
                else:
                    mask[1, 0] = 0

                if ((i5 - i6) >= 0 and (i7 - i6) >= 0) or ((i5 - i6) < 0 and (i7 - i6) < 0):
                    mask[0, 0] = 1
                else:
                    mask[0, 0] = 0

                if ((i6 - i7) >= 0 and (i8 - i7) >= 0) or ((i6 - i7) < 0 and (i8 - i7) < 0):
                    mask[0, 1] = 1
                else:
                    mask[0, 1] = 0

                if ((i7 - i8) >= 0 and (i1 - i8) >= 0) or ((i7 - i8) < 0 and (i1 - i8)< 0):
                    mask[0, 2] = 1
                else:
                    mask[0, 2] = 0
                result[i, j] = mask[1, 2] + mask[2, 2] * 128 + mask[2, 1] * 64 + mask[2, 0] * 32 + mask[1, 0] * 16 + mask[0,0] * 8 + mask[0, 1] * 4 + mask[0, 2] * 2
            else:
                if j <= y:
                    i1 = img[i, j]
                    i1 = np.mean(i1)
                else:
                    i1 = 0
                if i <= x and j <= y:
                    i2 = img[i, j]
                    i2 = np.mean(i2)
                else:
                    i2 = 0
                if i <= x:
                    i3 = img[i, j]
                    i3 = np.mean(i3)
                else:
                    i3 = 0
                if i <= x and j - 1 > 0:
                    i4 = img[i, j - 1]
                    i4 = np.mean(i4)
                else:
                    i4 = 0
                if j - 1 > 0:
                    i5 = img[i, j - 1]
                    i5 = np.mean(i5)
                else:
                    i5 = 0
                if i - 1 > 0 and j - 1 > 0:
                    i6 = img[i - 1, j - 1]
                    i6 = np.mean(i6)
                else:
                    i6 = 0
                if i - 1 > 0:
                    i7 = img[i - 1, j]
                    i7 = np.mean(i7)
                else:
                    i7 = 0
                if i - 1 > 0 and j <= y:
                    i8 = img[i - 1, j]
                    i8 = np.mean(i8)
                else:
                    i8 = 0
                if ((i8 - i1) >= 0 and (i2 - i1) >= 0) or ((i8 - i1) < 0 and (i2 - i1) < 0):
                    mask[1, 2] = 1
                else:
                    mask[1, 2] = 0

                if ((i3 - i2) >= 0 and (i1 - i2) >= 0) or ((i3 - i2) < 0 and (i1 - i2) < 0):
                    mask[2, 2] = 1
                else:
                    mask[2, 2] = 0

                if ((i4 - i3) >= 0 and (i2 - i3) >= 0) or ((i4 - i3) < 0 and (i2 - i3) < 0):
                    mask[2, 1] = 1
                else:
                    mask[2, 1] = 0

                if ((i5 - i4) >= 0 and (i3 - i4) >= 0) or ((i5 - i4) < 0 and (i3 - i4) < 0):
                    mask[2, 0] = 1
                else:
                    mask[2, 0] = 0

                if ((i4 - i5) >= 0 and (i6 - i5) >= 0) or ((i4 - i5) < 0 and (i6 - i5) < 0):
                    mask[1, 0] = 1
                else:
                    mask[1, 0] = 0

                if ((i5 - i6) >= 0 and (i7 - i6) >= 0) or ((i5 - i6) < 0 and (i7 - i6) < 0):
                    mask[0, 0] = 1
                else:
                    mask[0, 0] = 0

                if ((i6 - i7) >= 0 and (i8 - i7) >= 0) or ((i6 - i7) < 0 and (i8 - i7) < 0):
                    mask[0, 1] = 1
                else:
                    mask[0, 1] = 0

                if ((i7 - i8) >= 0 and (i1 - i8) >= 0) or ((i7 - i8) < 0 and (i1 - i8) < 0):
                    mask[0, 2] = 1
                else:
                    mask[0, 2] = 0
                result[i, j] = mask[1, 2] + mask[2, 2] * 128 + mask[2, 1] * 64 + mask[2, 0] * 32 + mask[1, 0] * 16 + + mask[0, 0] * 8 + mask[0, 1] * 4 + mask[0, 2] * 2
    hist, bins = np.histogram(result.ravel(), 50, [0, 50])
    plt.imshow(result, cmap="gray")
    # plt.show()
    return hist
