import matplotlib.pyplot as plt
plt.rcParams['figure.figsize'] = [10, 10]
import glob, re
import os, matplotlib.pyplot as plt
import cv2, numpy as np, pyfeats
from scipy.stats import kurtosis, skew
from keras.models import Model
from keras.applications.vgg19 import VGG19 as CNN
from skimage.feature.texture import graycoprops
import lndp, SLBT


base_model = CNN(weights='imagenet')
model = Model(inputs=base_model.input, outputs=base_model.get_layer('block4_pool').output)
# -------- CNN Features --------
def CNN_based(images):
    x = images
    x = np.expand_dims(x, axis=0)                           # expand the dimension
    x = np.resize(x, (1, 224, 224, 3))                      # resize the image to required format
    block4_pool_features = model.predict(x)                 # size(1, 14, 14, 512)
    mean_block_feat = block4_pool_features.mean(1)          # (1, 14, 512)
    feature_vec = mean_block_feat.mean(1)                   # (1, 512)
    return feature_vec[0].tolist()


def e_feat(images):
    energy = graycoprops(images, 'energy')
    return np.mean(energy)


def homo_feat(images):
    homoginity = graycoprops(images, 'homogeneity')
    return np.mean(homoginity)


def cuttt_mix(path1, path2):
    image_paths = []

    listing = os.listdir(path1)
    for file in listing:
        filename = os.path.join(path1, file)
        image_paths.append(filename)
    k = 1
    for m in range(len(listing)):
        image_batch = []
        image_batch_labels = []

        for i in range(100):
            image = cv2.cvtColor(cv2.imread(image_paths[i]), cv2.COLOR_BGR2RGB)
            image_batch.append(image)

            label_temp = list(np.floor(np.random.rand(1) * 2.99).astype(int))[0]
            if label_temp == 0:
                label = [1, 0, 0]
            elif label_temp == 1:
                label = [0, 1, 0]
            else:
                label = [0, 0, 1]

            image_batch_labels.append(label)

        # Convert image_batch to numpy array
        image_batch = np.array(image_batch)
        # Conver image_batch_labels to numpy array
        image_batch_labels = np.array(image_batch_labels)
        plt.imshow(image_batch[1 * 1])
        # plt.show()

        def rand_bbox(size, lamb):
            W = size[0]
            H = size[1]
            cut_rat = np.sqrt(1. - lamb)
            cut_w = (W * cut_rat).astype(int)
            cut_h = (H * cut_rat).astype(int)

            # uniform
            cx = np.random.randint(W)
            cy = np.random.randint(H)

            bbx1 = np.clip(cx - cut_w // 2, 0, W)
            bby1 = np.clip(cy - cut_h // 2, 0, H)
            bbx2 = np.clip(cx + cut_w // 2, 0, W)
            bby2 = np.clip(cy + cut_h // 2, 0, H)

            return bbx1, bby1, bbx2, bby2
        # Read an image
        image = cv2.cvtColor(cv2.imread(image_paths[m]), cv2.COLOR_BGR2RGB)

        # Crop a random bounding box
        lamb = 0.3
        size = image.shape
        bbox = rand_bbox(size, lamb)

        # Draw bounding box on the image
        im = image.copy()
        x1 = bbox[0]
        y1 = bbox[1]
        x2 = bbox[2]
        y2 = bbox[3]
        cv2.rectangle(im, (x1, y1), (x2, y2), (255, 0, 0), 3)
        plt.imshow(im)
        plt.title('Original image with random bounding box')
        # plt.show()
        # Show cropped image
        plt.imshow(image[y1:y2, x1:x2])
        # plt.title('Cropped image')
        # plt.show()

        def generate_cutmix_image(image_batch, image_batch_labels, beta):
            # generate mixed sample
            lam = np.random.beta(beta, beta)
            rand_index = np.random.permutation(len(image_batch))
            target_a = image_batch_labels
            target_b = image_batch_labels[rand_index]
            bbx1, bby1, bbx2, bby2 = rand_bbox(image_batch[0].shape, lam)
            image_batch_updated = image_batch.copy()
            image_batch_updated[:, bbx1:bbx2, bby1:bby2, :] = image_batch[rand_index, bbx1:bbx2, bby1:bby2, :]

            # adjust lambda to exactly match pixel ratio
            lam = 1 - ((bbx2 - bbx1) * (bby2 - bby1) / (image_batch.shape[1] * image_batch.shape[2]))
            label = target_a * lam + target_b * (1. - lam)

            return image_batch_updated, label

        # Generate CutMix image
        # Let's use the first image of the batch as the input image to be augmented
        input_image = image_batch[0]
        image_batch_updated, image_batch_labels_updated = generate_cutmix_image(image_batch, image_batch_labels, 1.0)

        plt.imshow(image_batch[1 * 1])
        # plt.show()

        image_batch_updated = image_batch_updated[1]
        plt.imshow(image_batch_updated)
        # plt.show()
        out_filename1 = os.path.join(path2, str(k) + '.png')
        # cv2.imwrite(out_filename1, image_batch_updated)
        k = k+1


# ------------------- Cutmix Augmentation -----------------
cuttt_mix('/....', 'cutmix')                                # Segmented image folder path and output path

# ------------------- Feature Extraction ------------------
im_path = glob.glob(".....//cutmix//*")
im_path.sort(key=lambda f: int(re.sub('\D', '', f)))

f1, f2, f3, f4, f5, f6, f7 = [], [], [], [], [], [], []
f8, f9, f10, f11, f12, f13 = [], [], [], [], [], []
Feature, Feature1 = [], []

for file in im_path:
    i_file = os.path.join(os.getcwd(), file)
    img = cv2.imread(i_file)

    # Mean
    mean = np.mean(img)
    f1 = mean
    # Variance
    var = np.var(img)
    f2 = var
    # Kurtosis
    kur = np.array(kurtosis(img)).flatten()
    f3.append(kur[10:20])
    # Skewness
    skewness = np.array(skew(img)).flatten()
    f4.append(skewness[10:20])
    #  contrast
    img1 = np.resize(img, (img.shape[0], img.shape[1], img.shape[0]))
    features, features_range, labels, labels_range = pyfeats.glcm_features(img1, ignore_zeros=False)
    f5 = features[1]
    # Homogeneity
    img1 = np.resize(img, (img.shape[0], img.shape[1], 3, 1))
    f6 = homo_feat(img1)
    # Correlation
    f7 = features[2]
    # Entropy
    f8 = features[8]
    # Energy
    f9 = e_feat(img1)
    # ASM
    f10 = features[0]
    # Shape local binary texture
    slbt = SLBT.SLBT(img)
    f11.append(slbt[:10])
    # local neighbourhood difference pattern
    LNDP = lndp.lndp(img1)
    f12.append(LNDP[:10])
    # CNN
    cnn = CNN_based(img)
    f13.append(cnn[:10])

    F = [f1, f2, f5, f6, f7, f8, f9, f10]
    F1 = np.concatenate((f3, f4, f11, f12, f13), axis=1)
    Feature.append(F)
    Feature1.append(F1[0])
    # np.save("cut1.npy", Feature)                                           # save output data into csv file
    # np.save("cut2.npy", Feature1)







