import numpy as np
import cv2 as cv
import matplotlib.pyplot as plt

src_f = 0
kernel_size =21
pos_sigma = 2

pos_lm=2
pos_th = 0
pos_gam = 10
pos_psi = 150


def Process():
	sig = pos_sigma
	lm = pos_lm+2
	th = pos_th*np.pi/180.
	gm = pos_gam/100.
	ps = (pos_psi-180)*np.pi/180
	print('kern_size=' + str(kernel_size) + ', sig=' + str(sig) + ', th=' + str(th) + ', lm=' + str(lm) +', gm=' + str(gm) + ', ps=' + str(ps))
	kernel = cv.getGaborKernel((kernel_size,kernel_size),sig,th,lm,gm,ps)
	kernelimg = kernel/2.+0.5
	global src_f
	dest = cv.filter2D(src_f, cv.CV_32F,kernel)
	cv.imshow('Process window', dest)
	cv.imshow('Kernel', cv.resize(kernelimg, (kernel_size*20,kernel_size*20)))
	cv.imshow('Mag', np.power(dest,2))


def SLBT(img):
	sig = pos_sigma
	lm = pos_lm+2
	th = pos_th*np.pi/180.
	gm = pos_gam/100.
	ps = (pos_psi-180)*np.pi/180
	kernel = cv.getGaborKernel((kernel_size, kernel_size), sig, th, lm, gm, ps)
	kernelimg = kernel/2.+0.5
	dest = cv.filter2D(img, cv.CV_32F, kernel)
	hist, bins = np.histogram(dest.ravel(), 50, [0, 50])
	plt.imshow(dest)
	# plt.show()
	return hist


def cb_sigma(pos):
	global pos_sigma
	if pos > 0:
		pos_sigma = pos
	else:
		pos_sigma = 1
	Process()


def cb_lm(pos):
	global pos_lm
	pos_lm = pos
	Process()


def cb_th(pos):
	global pos_th
	pos_th = pos
	Process()


def cb_psi(pos):
	global pos_psi
	pos_psi = pos
	Process()


def cb_gam(pos):
	global pos_gam
	pos_gam = pos
	Process()
